"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase";
import { User } from "@supabase/supabase-js";
import { Project, Template } from "@/lib/types";
import { cn } from "@/lib/utils";
import { ImportModal } from "./ImportModal";
import { SearchModal } from "./SearchModal";
import { WorkClock } from "./WorkClock";
import { ActiveTimerBadge } from "./ActiveTimerBadge";
import { fetchProjects as fetchProjectsQuery, fetchTemplates as fetchTemplatesQuery } from "@/lib/queries";
import {
  LayoutDashboard, ListChecks, RefreshCw, CalendarDays, ClipboardList,
  Map, BarChart3, Timer, Search, Download, ClipboardCopy, FolderPlus,
  ChevronDown, LogOut, Menu, X, CalendarRange, User as UserIcon, PieChart,
  BookUser, Palette, Clock,
} from "lucide-react";

export function Sidebar({ user }: { user: User }) {
  const pathname = usePathname();
  const router = useRouter();
  const [projects, setProjects] = useState<Project[]>([]);
  const [dragProjectIdx, setDragProjectIdx] = useState<number | null>(null);
  const [projectSort, setProjectSort] = useState<"custom" | "alpha" | "deadline">("custom");
  const [newProjectOpen, setNewProjectOpen] = useState(false);
  const [newProjectName, setNewProjectName] = useState("");
  const [templates, setTemplates] = useState<Template[]>([]);
  const [open, setOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [templateOpen, setTemplateOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [monthlyEnabled, setMonthlyEnabled] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const THEMES = [
    { id: "purple", label: "Purple", dot: "#9217BF" },
    { id: "ocean", label: "Ocean", dot: "#43B8FA" },
    { id: "emerald", label: "Emerald", dot: "#34d399" },
    { id: "ember", label: "Ember", dot: "#f0a050" },
    { id: "frost", label: "Frost ☀", dot: "#2563eb" },
    { id: "cloud", label: "Cloud ☀", dot: "#7c3aed" },
  ] as const;

  const [theme, setTheme] = useState("purple");

  // Init theme from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("comfy-theme") || "purple";
    setTheme(saved);
    document.documentElement.setAttribute("data-theme", saved === "purple" ? "" : saved);
    if (saved === "dawn" || saved === "frost") {
      document.documentElement.classList.remove("dark");
    }
  }, []);

  const cycleTheme = () => {
    const idx = THEMES.findIndex(t => t.id === theme);
    const next = THEMES[(idx + 1) % THEMES.length];
    setTheme(next.id);
    localStorage.setItem("comfy-theme", next.id);
    document.documentElement.setAttribute("data-theme", next.id === "purple" ? "" : next.id);
    // Toggle light/dark mode
    const isLight = next.id === "frost" || next.id === "cloud";
    if (isLight) {
      document.documentElement.classList.remove("dark");
      document.documentElement.style.colorScheme = "light";
    } else {
      document.documentElement.classList.add("dark");
      document.documentElement.style.colorScheme = "dark";
    }
  };

  // Load monthly routine toggle from localStorage
  useEffect(() => {
    setMonthlyEnabled(localStorage.getItem("comfy-monthly-routine") === "true");
    const handler = () => setMonthlyEnabled(localStorage.getItem("comfy-monthly-routine") === "true");
    window.addEventListener("monthly-routine-changed", handler);
    return () => window.removeEventListener("monthly-routine-changed", handler);
  }, []);

  // Close user menu on outside click
  useEffect(() => {
    if (!userMenuOpen) return;
    const handler = () => setUserMenuOpen(false);
    setTimeout(() => document.addEventListener("click", handler), 0);
    return () => document.removeEventListener("click", handler);
  }, [userMenuOpen]);

  const fetchProjects = useCallback(async () => {
    const supabase = createClient();
    setProjects(await fetchProjectsQuery(supabase, user.id));
  }, [user.id]);

  const fetchTemplates = useCallback(async () => {
    const supabase = createClient();
    setTemplates(await fetchTemplatesQuery(supabase, user.id));
  }, [user.id]);

  useEffect(() => {
    fetchProjects(); fetchTemplates();
    const handler = () => { fetchProjects(); fetchTemplates(); };
    window.addEventListener("projects-changed", handler);
    const supabase = createClient();
    const channel = supabase.channel("projects-sidebar")
      .on("postgres_changes", { event: "*", schema: "public", table: "projects", filter: `user_id=eq.${user.id}` }, () => fetchProjects())
      .subscribe();
    return () => { window.removeEventListener("projects-changed", handler); supabase.removeChannel(channel); };
  }, [user.id, fetchProjects, fetchTemplates]);

  // Global keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const isInput = target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable;

      // Ctrl/Cmd+K for search — works even in inputs
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setSearchOpen(true);
        return;
      }

      // Skip other shortcuts if in input
      if (isInput) return;

      // Quick nav shortcuts
      if (e.key === "d") { e.preventDefault(); router.push("/"); }
      if (e.key === "r") { e.preventDefault(); router.push("/routine"); }
      if (e.key === "e") { e.preventDefault(); router.push("/weekly-routine"); }
      if (e.key === "w") { e.preventDefault(); router.push("/week"); }
      if (e.key === "q") { e.preventDefault(); router.push("/tasks"); }
      if (e.key === "m") { e.preventDefault(); router.push("/roadmap"); }
      if (e.key === "t") { e.preventDefault(); router.push("/retro"); }
      if (e.key === "l") { e.preventDefault(); router.push("/deadlines"); }
      if (e.key === "n") { e.preventDefault(); handleNewProject(); }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [router]);

  const navItems: Array<{ href: string; icon: React.ReactNode; label: string; accent: string; key: string }> = [
    { href: "/", icon: <LayoutDashboard size={18} />, label: "Dashboard", accent: "violet", key: "D" },
    { href: "/routine", icon: <ListChecks size={18} />, label: "Daily Routine", accent: "red-acc", key: "R" },
    { href: "/weekly-routine", icon: <RefreshCw size={18} />, label: "Weekly Routine", accent: "violet", key: "E" },
    ...(monthlyEnabled ? [{ href: "/monthly-routine", icon: <CalendarRange size={18} />, label: "Monthly Routine", accent: "violet", key: "Y" }] : []),
    { href: "/week", icon: <CalendarDays size={18} />, label: "Calendar", accent: "violet", key: "W" },
    { href: "/tasks", icon: <ClipboardList size={18} />, label: "Task List", accent: "violet", key: "Q" },
    { href: "/roadmap", icon: <Map size={18} />, label: "Roadmap", accent: "violet", key: "M" },
    { href: "/retro", icon: <BarChart3 size={18} />, label: "Retro Planning", accent: "violet", key: "T" },
    { href: "/deadlines", icon: <Timer size={18} />, label: "Deadlines", accent: "violet", key: "L" },
  ];

  const handleSignOut = async () => {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/login");
  };

  const handleNewProject = () => {
    setNewProjectName("");
    setNewProjectOpen(true);
  };

  const createProject = async (title: string) => {
    if (!title.trim()) return;
    const supabase = createClient();
    const { data } = await supabase.from("projects")
      .insert({ user_id: user.id, title: title.trim(), sort_order: projects.length })
      .select().single();
    if (data) { window.dispatchEvent(new Event("projects-changed")); router.push(`/projects/${data.id}`); }
    setNewProjectOpen(false);
  };

  const createFromTemplate = async (template: Template) => {
    setNewProjectName(template.name);
    setNewProjectOpen(true);
    // Store template for use after modal submit
    pendingTemplateRef.current = template;
  };

  const pendingTemplateRef = useRef<Template | null>(null);

  const handleProjectModalSubmit = async () => {
    const title = newProjectName.trim();
    if (!title) return;
    const template = pendingTemplateRef.current;
    pendingTemplateRef.current = null;
    setNewProjectOpen(false);

    if (!template) {
      await createProject(title);
      return;
    }

    // Create from template
    const supabase = createClient();
    const { data: proj } = await supabase.from("projects")
      .insert({ user_id: user.id, title, sort_order: projects.length })
      .select().single();
    if (!proj) return;

    const tasksData = template.task_data as Array<{
      name: string; est_minutes?: number; deadline?: string | null; notes?: string;
      subtasks?: Array<{ name: string; est_minutes?: number; deadline?: string | null; notes?: string }>;
    }>;
    for (let i = 0; i < tasksData.length; i++) {
      const t = tasksData[i];
      const dl = t.deadline && t.deadline !== "\u2014" ? t.deadline : null;
      const { data: task } = await supabase.from("project_tasks").insert({
        project_id: proj.id, user_id: user.id, name: t.name, est_minutes: t.est_minutes || 0,
        deadline: dl, progress: 0, notes: t.notes || "", elapsed_seconds: 0, sort_order: i,
      }).select().single();
      if (task && t.subtasks) {
        for (let j = 0; j < t.subtasks.length; j++) {
          const s = t.subtasks[j];
          await supabase.from("subtasks").insert({
            task_id: task.id, user_id: user.id, name: s.name, est_minutes: s.est_minutes || 0,
            deadline: s.deadline && s.deadline !== "\u2014" ? s.deadline : null,
            progress: 0, notes: s.notes || "", sort_order: j,
          });
        }
      }
    }
    setTemplateOpen(false);
    window.dispatchEvent(new Event("projects-changed"));
    router.push(`/projects/${proj.id}`);
  };

  const deleteTemplate = async (id: string) => {
    if (!confirm("Delete this template?")) return;
    const supabase = createClient();
    await supabase.from("templates").delete().eq("id", id);
    setTemplates((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <>
      <button onClick={() => setOpen(!open)}
        className="fixed top-3 left-3 z-50 md:hidden w-10 h-10 flex items-center justify-center bg-surface2 rounded-lg border border-border">
        <span className="text-lg">{open ? <X size={20} /> : <Menu size={20} />}</span>
      </button>
      {open && <div className="fixed inset-0 bg-black/50 z-30 md:hidden" onClick={() => setOpen(false)} />}

      <aside className={cn(
        "fixed top-0 left-0 h-full w-60 bg-surface border-r border-border z-40 flex flex-col transition-transform duration-200",
        !open && "-translate-x-full md:translate-x-0"
      )}>
        <div className="p-4 border-b border-border">
          <h1 className="font-title text-lg text-bright tracking-wide">Comfy Board</h1>
          <div className="relative mt-1">
            <button onClick={() => setUserMenuOpen(!userMenuOpen)}
              className="flex items-center gap-2 text-xs text-txt3 hover:text-txt transition-colors w-full">
              <UserIcon size={13} />
              <span className="truncate flex-1 text-left">{user.email}</span>
              <ChevronDown size={12} className={cn("transition-transform", userMenuOpen && "rotate-180")} />
            </button>
            {userMenuOpen && (
              <div className="absolute left-0 top-full mt-1 bg-surface2 border border-border rounded-lg shadow-xl py-1 w-full z-50">
                <Link href="/stats" onClick={() => { setUserMenuOpen(false); setOpen(false); }}
                  className="flex items-center gap-2 px-3 py-2 text-xs text-txt2 hover:bg-surface3 transition-colors w-full">
                  <PieChart size={13} /> Stats & Activity
                </Link>
                <div className="border-t border-border my-1" />
                <div className="px-3 py-1">
                  <span className="text-[10px] text-txt3 uppercase tracking-wider">Theme</span>
                </div>
                {THEMES.map(t => (
                  <button key={t.id} onClick={(e) => {
                    e.stopPropagation();
                    setTheme(t.id);
                    localStorage.setItem("comfy-theme", t.id);
                    document.documentElement.setAttribute("data-theme", t.id === "purple" ? "" : t.id);
                    const isLight = t.id === "frost" || t.id === "cloud";
                    if (isLight) {
                      document.documentElement.classList.remove("dark");
                      document.documentElement.style.colorScheme = "light";
                    } else {
                      document.documentElement.classList.add("dark");
                      document.documentElement.style.colorScheme = "dark";
                    }
                  }}
                    className="flex items-center gap-2 px-3 py-1.5 text-xs text-txt2 hover:bg-surface3 transition-colors w-full">
                    <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: t.dot }} />
                    <span className="flex-1 text-left">{t.label}</span>
                    {theme === t.id && <span className="text-[10px] text-violet2">✓</span>}
                  </button>
                ))}
                <div className="border-t border-border my-1" />
                <button onClick={handleSignOut}
                  className="flex items-center gap-2 px-3 py-2 text-xs text-txt3 hover:text-danger hover:bg-surface3 transition-colors w-full">
                  <LogOut size={13} /> Sign out
                </button>
              </div>
            )}
          </div>
        </div>

        <button onClick={() => setSearchOpen(true)}
          className="mx-2 mt-2 flex items-center gap-2 px-3 py-2 rounded-lg bg-surface2 border border-border text-sm text-txt3 hover:text-txt hover:border-border2 transition-colors">
          <span><Search size={14} /></span><span className="flex-1 text-left">Search...</span>
          <kbd className="text-[9px] bg-surface3 px-1 py-0.5 rounded">⌘K</kbd>
        </button>

        <nav className="flex-1 overflow-y-auto p-2 space-y-1 mt-1">
          {navItems.map((item) => {
            const active = item.href === "/" ? pathname === "/" : (pathname === item.href || pathname.startsWith(item.href + "/"));
            return (
              <Link key={item.href} href={item.href} onClick={() => setOpen(false)}
                className={cn("flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
                  active ? "" : "text-txt2 hover:bg-surface2 hover:text-txt")}
                style={active ? {
                  backgroundColor: "color-mix(in srgb, var(--accent) 15%, transparent)",
                  color: "var(--accent2)",
                } : undefined}>
                <span className="w-5 h-5 flex items-center justify-center shrink-0">{item.icon}</span>
                <span className="flex-1">{item.label}</span>
                {item.key && <kbd className="text-[9px] text-txt3 bg-surface3 px-1 py-0.5 rounded">{item.key}</kbd>}
              </Link>
            );
          })}

          <div className="border-t border-border my-3" />

          <div className="px-3 mb-1 flex items-center justify-between">
            <Link href="/projects" onClick={() => setOpen(false)}
              className="text-[11px] uppercase tracking-wider text-txt3 hover:text-red-acc transition-colors">Projects</Link>
            <div className="flex items-center gap-1">
              <button onClick={() => setProjectSort(s => s === "custom" ? "alpha" : s === "alpha" ? "deadline" : "custom")}
                title={`Sort: ${projectSort}`}
                className="text-[9px] text-txt3 hover:text-txt transition-colors px-1 py-0.5 rounded bg-surface3">
                {projectSort === "custom" ? "⠿" : projectSort === "alpha" ? "AZ" : "📅"}
              </button>
              <button onClick={() => setImportOpen(true)} title="Import" className="text-txt3 hover:text-green-acc transition-colors p-0.5"><Download size={14} /></button>
              <button onClick={() => { fetchTemplates(); setTemplateOpen(!templateOpen); }} title="Templates" className="text-txt3 hover:text-violet2 transition-colors p-0.5"><ClipboardCopy size={14} /></button>
            </div>
          </div>

          {templateOpen && (
            <div className="mx-2 mb-2 bg-surface2 border border-border rounded-lg overflow-hidden">
              {templates.length === 0 ? (
                <p className="text-[11px] text-txt3 px-3 py-2 text-center">No templates</p>
              ) : templates.map((t) => (
                <div key={t.id} className="flex items-center border-b border-border/50 last:border-b-0 group">
                  <button onClick={() => createFromTemplate(t)}
                    className="flex-1 text-left px-3 py-2 text-xs text-txt2 hover:bg-surface3 hover:text-violet2 truncate">
                    <ClipboardCopy size={12} className="shrink-0" /> {t.name}
                  </button>
                  <button onClick={() => deleteTemplate(t.id)}
                    className="px-2 py-2 text-xs text-txt3 hover:text-danger opacity-0 group-hover:opacity-100 transition-all">✕</button>
                </div>
              ))}
            </div>
          )}

          {(() => {
            const sorted = projectSort === "alpha"
              ? [...projects].sort((a, b) => a.title.localeCompare(b.title))
              : projectSort === "deadline"
              ? [...projects].sort((a, b) => {
                  if (!a.deadline && !b.deadline) return 0;
                  if (!a.deadline) return 1;
                  if (!b.deadline) return -1;
                  return a.deadline.localeCompare(b.deadline);
                })
              : projects;
            return sorted.map((p, idx) => {
            const active = pathname === `/projects/${p.id}`;
            return (
              <div key={p.id}
                draggable
                onClick={() => { router.push(`/projects/${p.id}`); setOpen(false); }}
                onDragStart={() => setDragProjectIdx(idx)}
                onDragOver={(e) => { e.preventDefault(); if (dragProjectIdx !== null && dragProjectIdx !== idx) {
                  setProjects(prev => {
                    const copy = [...prev];
                    const [item] = copy.splice(dragProjectIdx!, 1);
                    copy.splice(idx, 0, item);
                    return copy;
                  });
                  setDragProjectIdx(idx);
                }}}
                onDragEnd={() => {
                  setDragProjectIdx(null);
                  const supabase = createClient();
                  projects.forEach((proj, i) => supabase.from("projects").update({ sort_order: i }).eq("id", proj.id));
                }}
                className={cn("flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors truncate cursor-grab select-none",
                  active ? "" : "text-txt2 hover:bg-surface2 hover:text-txt")}
                style={active ? { backgroundColor: `${p.color || "#e05555"}20`, color: p.color || "#e05555" } : undefined}>
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: p.color || "#e05555" }} />
                <span className="truncate">{p.title}</span>
              </div>
            );
          });
          })()}

          <button onClick={handleNewProject}
            className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-txt3 hover:bg-surface2 hover:text-txt w-full transition-colors">
            <FolderPlus size={16} className="shrink-0" /><span>New Project</span>
            <kbd className="text-[9px] text-txt3 bg-surface3 px-1 py-0.5 rounded ml-auto">N</kbd>
          </button>
        </nav>

        <div className="p-3 border-t border-border space-y-1">
          <ActiveTimerBadge userId={user.id} />
          <WorkClock userId={user.id} />
          <button onClick={() => window.dispatchEvent(new Event("toggle-contacts"))}
            className="flex items-center gap-2 w-full px-2 py-2 rounded-lg text-xs text-txt3 hover:bg-surface2 hover:text-txt transition-colors">
            <BookUser size={15} /> <span>Contacts</span>
            <span className="ml-auto text-[9px] text-txt3">→</span>
          </button>
          <button onClick={() => window.dispatchEvent(new Event("toggle-monitoring"))}
            className="flex items-center gap-2 w-full px-2 py-2 rounded-lg text-xs text-txt3 hover:bg-surface2 hover:text-amber transition-colors">
            <Clock size={15} /> <span>Monitoring</span>
            <span className="ml-auto text-[9px] text-txt3">←</span>
          </button>
          <div className="text-[10px] text-txt3 px-2 space-y-0.5">
            <p><kbd className="bg-surface3 px-1 py-0.5 rounded">⌘K</kbd> Search · <kbd className="bg-surface3 px-1 py-0.5 rounded">D</kbd> Home · <kbd className="bg-surface3 px-1 py-0.5 rounded">R</kbd> Routine · <kbd className="bg-surface3 px-1 py-0.5 rounded">W</kbd> Calendar · <kbd className="bg-surface3 px-1 py-0.5 rounded">M</kbd> Map · <kbd className="bg-surface3 px-1 py-0.5 rounded">N</kbd> New</p>
          </div>
        </div>
      </aside>

      <ImportModal open={importOpen} onClose={() => setImportOpen(false)} userId={user.id}
        onComplete={() => { fetchProjects(); window.dispatchEvent(new Event("projects-changed")); }} />
      <SearchModal open={searchOpen} onClose={() => setSearchOpen(false)} />

      {/* New Project Modal */}
      {newProjectOpen && (
        <>
          <div className="fixed inset-0 z-[199]" style={{ background: "rgba(0,0,0,0.5)", backdropFilter: "blur(4px)" }}
            onClick={() => { setNewProjectOpen(false); pendingTemplateRef.current = null; }} />
          <div className="fixed z-[200] w-[90vw] max-w-sm rounded-2xl p-6"
            style={{
              top: "50%", left: "50%", transform: "translate(-50%, -50%)",
              background: "color-mix(in srgb, var(--surface) 95%, transparent)",
              border: "1px solid var(--border)",
              boxShadow: "0 24px 48px rgba(0,0,0,0.4)",
            }}>
            <h3 className="text-lg font-semibold text-bright mb-4">New Project</h3>
            <input
              autoFocus
              value={newProjectName}
              onChange={(e) => setNewProjectName(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") handleProjectModalSubmit(); if (e.key === "Escape") { setNewProjectOpen(false); pendingTemplateRef.current = null; } }}
              placeholder="Project name"
              className="w-full bg-surface2 border border-border rounded-lg px-4 py-3 text-txt text-sm mb-4 focus:outline-none focus:border-violet"
            />
            <div className="flex justify-end gap-2">
              <button onClick={() => { setNewProjectOpen(false); pendingTemplateRef.current = null; }}
                className="px-4 py-2 text-sm text-txt3 hover:text-txt transition-colors">Cancel</button>
              <button onClick={handleProjectModalSubmit} disabled={!newProjectName.trim()}
                className="px-4 py-2 text-sm bg-violet text-white rounded-lg hover:opacity-90 disabled:opacity-40 transition-colors">Create</button>
            </div>
          </div>
        </>
      )}
    </>
  );
}
